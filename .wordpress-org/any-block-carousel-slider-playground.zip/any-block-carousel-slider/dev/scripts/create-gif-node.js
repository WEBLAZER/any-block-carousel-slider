#!/usr/bin/env node

/**
 * Script pour convertir icon.svg animé en icon-256x256.gif
 * Nécessite : Node.js et puppeteer
 * 
 * Installation :
 *   npm install puppeteer
 * 
 * Usage :
 *   node create-gif-node.js
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Calculer le chemin du plugin
// Le script est dans dev/scripts/, on remonte de 2 niveaux pour arriver au plugin
const PLUGIN_DIR = path.resolve(__dirname, '../..');
const SVG_FILE = path.join(PLUGIN_DIR, '.wordpress-org/icon.svg');
const OUTPUT_GIF = path.join(PLUGIN_DIR, '.wordpress-org/icon-256x256.gif');
const TEMP_DIR = path.join(PLUGIN_DIR, '.wordpress-org/temp-frames');

// Vérifier que les fichiers existent
if (!fs.existsSync(SVG_FILE)) {
    console.error(`❌ Fichier SVG introuvable : ${SVG_FILE}`);
    console.log(`   Répertoire du plugin : ${PLUGIN_DIR}`);
    console.log(`   __dirname : ${__dirname}`);
    process.exit(1);
}

// Vérifier que puppeteer est installé
let puppeteer;
try {
    puppeteer = require('puppeteer');
} catch (e) {
    console.error('❌ Puppeteer n\'est pas installé');
    console.log('\n📦 Installation :');
    console.log('   cd ' + PLUGIN_DIR);
    console.log('   npm install puppeteer');
    process.exit(1);
}

// Vérifier que ImageMagick est installé (pour créer le GIF)
try {
    execSync('which convert', { stdio: 'ignore' });
} catch (e) {
    console.error('❌ ImageMagick n\'est pas installé');
    console.log('\n📦 Installation (macOS) :');
    console.log('   brew install imagemagick');
    process.exit(1);
}

async function createGif() {
    console.log('🎬 Démarrage de la conversion SVG → GIF...\n');

    // Créer le dossier temporaire pour les frames
    if (!fs.existsSync(TEMP_DIR)) {
        fs.mkdirSync(TEMP_DIR, { recursive: true });
    }

    // Lire le SVG
    let svgContent = fs.readFileSync(SVG_FILE, 'utf8');

    // Modifier le SVG pour désactiver l'animation infinie dès le départ
    // Remplacer "infinite" par "1" dans l'animation pour qu'elle ne tourne qu'une fois
    svgContent = svgContent.replace(
        /animation:\s*slideMove\s+4s\s+linear\s+infinite/g,
        'animation: slideMove 4s linear 1'
    );

    // Créer une page HTML pour afficher le SVG avec fond transparent
    const html = `
<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: transparent !important;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 256px;
            height: 256px;
        }
        html {
            background: transparent !important;
        }
    </style>
</head>
<body>
    ${svgContent}
</body>
</html>`;

    console.log('🚀 Lancement du navigateur...');
    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--transparent']
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 256, height: 256 });

    // Définir un fond transparent pour la page
    await page.setContent(html, { waitUntil: 'networkidle0' });

    // Attendre que le SVG soit rendu
    await page.evaluate(() => {
        return new Promise(resolve => {
            const svg = document.querySelector('svg');
            if (svg && svg.complete) {
                resolve();
            } else {
                setTimeout(resolve, 100);
            }
        });
    });

    // Attendre que l'animation soit chargée
    console.log('⏳ Attente du chargement de l\'animation...');
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Attendre que l'animation soit au début (translateX(0))
    // L'animation dure 4 secondes, donc on attend jusqu'à ce qu'elle soit à 0
    console.log('🔄 Attente que l\'animation soit au début (translateX(0))...');
    const animationDuration = 4; // secondes
    let isAtStart = false;
    let waitAttempts = 0;
    const maxWaitAttempts = 50; // Maximum 5 secondes

    while (!isAtStart && waitAttempts < maxWaitAttempts) {
        const currentTransform = await page.evaluate(() => {
            const slideContainer = document.querySelector('.slide-container');
            if (slideContainer) {
                const style = window.getComputedStyle(slideContainer);
                return style.transform;
            }
            return 'none';
        });

        // Vérifier si on est à translateX(0) - matrix(1, 0, 0, 1, 0, 0) ou très proche
        let isZero = currentTransform === 'none' || currentTransform === 'matrix(1, 0, 0, 1, 0, 0)';

        if (!isZero && currentTransform.includes('matrix')) {
            // Extraire la valeur X de la transformation matrix(a, b, c, d, x, y)
            const match = currentTransform.match(/matrix\([^,]+,\s*[^,]+,\s*[^,]+,\s*[^,]+,\s*([^,)]+)/);
            if (match && match[1]) {
                const xValue = parseFloat(match[1]);
                isZero = Math.abs(xValue) < 5; // Tolérance de 5px
            }
        }

        if (isZero) {
            isAtStart = true;
            console.log(`   Animation au début (tentative ${waitAttempts + 1})`);
            break;
        }

        await new Promise(resolve => setTimeout(resolve, 100));
        waitAttempts++;
    }

    // Maintenant arrêter l'animation et la relancer avec 1 itération
    console.log('🔄 Arrêt de l\'animation...');
    await page.evaluate(() => {
        const slideContainer = document.querySelector('.slide-container');
        if (slideContainer) {
            slideContainer.style.animation = 'none';
            slideContainer.style.transform = 'translateX(0)';
            void slideContainer.offsetWidth;
        }
    });

    await new Promise(resolve => setTimeout(resolve, 100));

    // Utiliser JavaScript pour animer manuellement la transformation
    // Cela nous donne un contrôle total sur le timing
    console.log('▶️  Lancement de l\'animation manuelle (1 itération)...');

    // Arrêter l'animation CSS et utiliser JavaScript pour animer
    await page.evaluate(() => {
        const slideContainer = document.querySelector('.slide-container');
        if (slideContainer) {
            // Arrêter l'animation CSS
            slideContainer.style.animation = 'none';
            // Commencer à translateX(0)
            slideContainer.style.transform = 'translateX(0)';
        }
    });

    await new Promise(resolve => setTimeout(resolve, 50));

    const captureFps = 30; // Fréquence de capture (30 images par seconde pour une animation très fluide)
    const totalFrames = Math.floor(captureFps * animationDuration); // 120 frames pour 4 secondes à 30 fps
    const frameDelay = 1000 / captureFps; // ~33ms entre chaque capture

    console.log(`📸 Capture de ${totalFrames} frames à ${captureFps} fps pendant ${animationDuration}s...`);
    console.log(`   Animation lancée une seule fois, capture à vitesse normale`);

    const startTime = Date.now();

    // Vérifier la transformation initiale
    const initialTransform = await page.evaluate(() => {
        const slideContainer = document.querySelector('.slide-container');
        return slideContainer ? window.getComputedStyle(slideContainer).transform : 'none';
    });
    console.log(`   Transform initiale : ${initialTransform}`);

    for (let i = 0; i < totalFrames; i++) {
        // Calculer le temps écoulé depuis le début de la capture (pas depuis animationStartTime)
        // Chaque frame doit correspondre à un moment précis de l'animation de 4 secondes
        const progress = Math.min(i / totalFrames, 1); // 0 à 1 basé sur le numéro de frame

        // Calculer la transformation selon l'animation slideMove
        // Animation slideMove : 
        // 0-25% : translateX(0) (slide 1)
        // 25-50% : translateX(0) → translateX(-242) (transition)
        // 50-75% : translateX(-242) (slide 2)
        // 75-100% : translateX(-242) → translateX(0) (retour instantané, mais on ne capture que jusqu'à 75%)

        let translateX = 0;
        if (progress <= 0.25) {
            // 0-25% : slide 1 visible
            translateX = 0;
        } else if (progress <= 0.50) {
            // 25-50% : transition de 0 à -242
            const transitionProgress = (progress - 0.25) / 0.25; // 0 à 1
            translateX = -242 * transitionProgress;
        } else {
            // 50-75% : slide 2 visible
            translateX = -242;
        }

        // Appliquer la transformation
        await page.evaluate((tx) => {
            const slideContainer = document.querySelector('.slide-container');
            if (slideContainer) {
                slideContainer.style.transform = `translateX(${tx}px)`;
            }
        }, translateX);


        const framePath = path.join(TEMP_DIR, `frame-${String(i).padStart(3, '0')}.png`);
        await page.screenshot({
            path: framePath,
            clip: { x: 0, y: 0, width: 256, height: 256 },
            omitBackground: true // Fond transparent
        });

        // Calculer le temps écoulé et ajuster le délai pour rester synchronisé
        const elapsedTime = Date.now() - startTime;
        const expectedTime = (i + 1) * frameDelay;
        const waitTime = Math.max(0, expectedTime - elapsedTime);

        if (waitTime > 0) {
            await new Promise(resolve => setTimeout(resolve, waitTime));
        }

        if ((i + 1) % captureFps === 0) {
            process.stdout.write(`\r   ${i + 1}/${totalFrames} frames capturées...`);
        }
    }

    // Arrêter l'animation après la capture
    await page.evaluate(() => {
        const slideContainer = document.querySelector('.slide-container');
        if (slideContainer) {
            slideContainer.style.animation = 'none';
        }
    });

    console.log('\n✅ Frames capturées');
    console.log('🎨 Application de la transparence sur les frames...');

    // Lister tous les fichiers frames dans l'ordre
    const frameFiles = fs.readdirSync(TEMP_DIR)
        .filter(file => file.startsWith('frame-') && file.endsWith('.png'))
        .sort()
        .map(file => path.join(TEMP_DIR, file));

    // Rendre le fond bleu transparent dans chaque frame
    // Le fond bleu WordPress est #0073AA, mais on accepte une tolérance pour les variations
    let convertCmd = 'convert';
    let isMagick = false;
    try {
        execSync('which magick', { stdio: 'ignore' });
        convertCmd = 'magick';
        isMagick = true;
    } catch (e) {
        convertCmd = 'convert';
    }

    const bgColor = '#0073AA'; // Couleur du fond bleu WordPress

    // Traiter chaque frame pour rendre le fond transparent
    for (const frameFile of frameFiles) {
        if (isMagick) {
            // ImageMagick v7 : syntaxe différente
            execSync(`${convertCmd} "${frameFile}" -fuzz 5% -transparent "${bgColor}" -write "${frameFile}" null:`, { stdio: 'ignore' });
        } else {
            // ImageMagick v6 : syntaxe classique
            execSync(`${convertCmd} "${frameFile}" -fuzz 5% -transparent "${bgColor}" "${frameFile}"`, { stdio: 'ignore' });
        }
    }

    console.log('🎞️  Création du GIF avec transparence...');

    // Créer le GIF avec les frames transparentes
    // Le délai en ImageMagick est en centièmes de seconde (100 = 1 seconde)
    // Pour 30 fps : chaque frame doit durer ~0.033s = 3.333/100 seconde
    // Pour 120 frames à ~0.033s chacune : 120 × 0.033s = 4 secondes (parfait !)
    const gifDelay = (1000 / captureFps) / 10; // 100ms = 10 en unités ImageMagick (100 = 1 seconde)

    console.log(`   Délai par frame dans le GIF : ${gifDelay}/100 seconde (${(gifDelay / 100).toFixed(3)}s)`);
    console.log(`   Durée totale du GIF : ${(totalFrames * gifDelay / 100).toFixed(2)} secondes`);

    // ImageMagick peut accepter des décimales dans certaines versions
    // Sinon, on peut utiliser une valeur légèrement différente pour compenser
    // Pour 4 secondes avec 120 frames : delay = 400/120 = 3.333...
    // Si arrondi à 3 : 120 × 3/100 = 3.6s (trop rapide)
    // Si on utilise 4 : 120 × 4/100 = 4.8s (trop lent)
    // Solution : utiliser le délai exact avec décimales si supporté


    let cmd;
    // Le problème : ImageMagick peut interpréter le délai différemment
    // Pour être sûr d'avoir exactement 4 secondes, on peut :
    // 1. Utiliser un délai plus précis
    // 2. Ou ajuster pour que la durée totale soit correcte

    // Calculer le délai pour avoir exactement 4 secondes
    // Si on a 120 frames et qu'on veut 4 secondes : delay = 400/120 = 3.333...
    // Mais ImageMagick peut arrondir, donc testons avec une valeur plus précise

    // Pour ImageMagick v7, on peut utiliser des décimales
    // Pour ImageMagick v6, on doit arrondir mais on peut compenser en ajustant légèrement

    // Utiliser le délai calculé (~3.333 pour ≈0.033s par frame)
    // 120 frames × 0.033s ≈ 4 secondes exactement
    if (isMagick) {
        cmd = `${convertCmd} -delay ${gifDelay} -loop 0 ${frameFiles.map(f => `"${f}"`).join(' ')} "${OUTPUT_GIF}"`;
    } else {
        cmd = `${convertCmd} -delay ${gifDelay} -loop 0 ${frameFiles.map(f => `"${f}"`).join(' ')} "${OUTPUT_GIF}"`;
    }

    execSync(cmd, { stdio: 'inherit' });

    // Nettoyer
    console.log('🧹 Nettoyage des fichiers temporaires...');
    fs.readdirSync(TEMP_DIR).forEach(file => {
        fs.unlinkSync(path.join(TEMP_DIR, file));
    });
    fs.rmdirSync(TEMP_DIR);

    await browser.close();

    console.log(`\n✅ GIF créé avec succès : ${OUTPUT_GIF}`);
    console.log(`📊 Taille : ${(fs.statSync(OUTPUT_GIF).size / 1024).toFixed(2)} KB`);
}

createGif().catch(error => {
    console.error('❌ Erreur :', error);
    process.exit(1);
});

