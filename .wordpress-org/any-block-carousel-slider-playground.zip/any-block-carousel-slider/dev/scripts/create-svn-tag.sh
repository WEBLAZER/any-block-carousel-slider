#!/bin/bash

# Script pour créer un tag SVN depuis trunk
# Usage: ./scripts/create-svn-tag.sh 1.0.2

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

SVN_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider-svn"

# Vérifier la version
if [ -z "$1" ]; then
    echo -e "${RED}❌ Usage: $0 <version>${NC}"
    echo "Exemple: $0 1.0.2"
    exit 1
fi

VERSION=$1
TAG_DIR="$SVN_DIR/tags/$VERSION"

# Vérifier que le tag n'existe pas déjà
if [ -d "$TAG_DIR" ]; then
    echo -e "${RED}❌ Le tag $VERSION existe déjà!${NC}"
    exit 1
fi

cd "$SVN_DIR"

# Mettre à jour trunk
echo -e "${YELLOW}🔄 Mise à jour trunk...${NC}"
svn update trunk

# Créer le tag depuis trunk (avec URL complète pour éviter les erreurs)
echo -e "${YELLOW}🏷️  Création du tag $VERSION...${NC}"
svn copy https://plugins.svn.wordpress.org/native-blocks-carousel/trunk https://plugins.svn.wordpress.org/native-blocks-carousel/tags/$VERSION -m "Tag version $VERSION: Release $VERSION"

# Mettre à jour le dépôt local pour récupérer le tag
echo -e "${YELLOW}🔄 Mise à jour du dépôt local...${NC}"
svn update

echo -e "${GREEN}✅ Tag $VERSION créé avec succès!${NC}"
echo -e "${GREEN}   URL: https://wordpress.org/plugins/any-block-carousel-slider/developers/${NC}"

