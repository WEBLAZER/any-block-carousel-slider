#!/bin/bash

# Script de synchronisation Git → SVN trunk
# Usage: ./scripts/sync-to-svn.sh

set -e

# Couleurs pour les messages
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Chemins
GIT_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider"
SVN_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider-svn"

echo -e "${YELLOW}🔄 Synchronisation Git → SVN trunk...${NC}"

# Vérifier que nous sommes dans le bon répertoire Git
cd "$GIT_DIR"
if [ ! -d ".git" ]; then
    echo -e "${RED}❌ Erreur: Pas un dépôt Git valide${NC}"
    exit 1
fi

# Vérifier que le dépôt SVN existe
if [ ! -d "$SVN_DIR/.svn" ]; then
    echo -e "${RED}❌ Erreur: Dépôt SVN non trouvé. Exécutez d'abord: svn checkout${NC}"
    exit 1
fi

# Liste des fichiers à synchroniser (exclure les fichiers de dev)
FILES_TO_SYNC=(
    "any-block-carousel-slider.php"
    "readme.txt"
    "LICENSE"
    "includes"
    "assets"
    "languages"
)

# Copier les fichiers
echo -e "${YELLOW}📁 Copie des fichiers...${NC}"
for file in "${FILES_TO_SYNC[@]}"; do
    if [ -e "$GIT_DIR/$file" ]; then
        echo "  → $file"
        if [ -d "$GIT_DIR/$file" ]; then
            rsync -av --delete "$GIT_DIR/$file/" "$SVN_DIR/trunk/$file/" --exclude='.git' --exclude='node_modules' --exclude='.DS_Store' --exclude='._*' --exclude='*.swp'
        else
            cp "$GIT_DIR/$file" "$SVN_DIR/trunk/$file"
        fi
    fi
done

# Exclure les fichiers de développement
echo -e "${YELLOW}🧹 Nettoyage des fichiers de dev...${NC}"
cd "$SVN_DIR/trunk"
# Supprimer le dossier dev/ complet (contient tout le développement)
rm -rf dev/ 2>/dev/null || true
# Supprimer tous les fichiers .md (documentation de dev)
find . -name "*.md" -type f -delete 2>/dev/null || true
# Supprimer les fichiers Git (ne doivent pas être dans SVN)
rm -rf .git 2>/dev/null || true
# Supprimer les fichiers .gitignore (SVN utilise svn:ignore, pas .gitignore)
find . -name ".gitignore" -type f -delete 2>/dev/null || true
# Supprimer les fichiers macOS (resource forks)
find . -name "._*" -type f -delete 2>/dev/null || true
find . -name ".DS_Store" -type f -delete 2>/dev/null || true

# Copier les assets WordPress.org vers /assets/ à la racine du dépôt SVN
# Selon la documentation: https://developer.wordpress.org/plugins/wordpress-org/how-to-use-subversion/
# Les screenshots, headers et icons doivent être dans /assets/ à la racine, pas dans trunk
if [ -d "$GIT_DIR/.wordpress-org" ]; then
    echo -e "${YELLOW}📸 Copie des assets WordPress.org vers /assets/...${NC}"
    rsync -av --delete "$GIT_DIR/.wordpress-org/" "$SVN_DIR/assets/" --exclude='.git' --exclude='.DS_Store' --exclude='._*' --exclude='*.swp'
    echo "  → Assets copiés vers /assets/"
fi

# Vérifier les modifications SVN
cd "$SVN_DIR"
echo -e "${YELLOW}📊 Statut SVN:${NC}"
svn status

# Demander confirmation avant commit
read -p "Voulez-vous commit et push vers SVN? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    read -p "Message de commit: " commit_message
    if [ -z "$commit_message" ]; then
        commit_message="Sync from Git: $(date +%Y-%m-%d)"
    fi
    
    svn add --force trunk/ 2>/dev/null || true
    svn add --force assets/ 2>/dev/null || true
    svn commit -m "$commit_message"
    echo -e "${GREEN}✅ Synchronisation terminée!${NC}"
else
    echo -e "${YELLOW}⚠️  Modifications préparées mais non commitées${NC}"
fi

