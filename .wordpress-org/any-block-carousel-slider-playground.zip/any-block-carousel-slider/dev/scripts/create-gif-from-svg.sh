#!/bin/bash

# Script pour convertir icon.svg animé en icon-256x256.gif
# Nécessite : ImageMagick ou GIMP avec script-fu

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_DIR="$(dirname "$(dirname "$(dirname "$SCRIPT_DIR")")")"
SVG_FILE="$PLUGIN_DIR/.wordpress-org/icon.svg"
OUTPUT_GIF="$PLUGIN_DIR/.wordpress-org/icon-256x256.gif"

echo "🎬 Conversion de icon.svg en GIF animé..."

# Méthode 1 : Utiliser GIMP avec script-fu (si GIMP installé)
if command -v gimp &> /dev/null; then
    echo "✅ GIMP détecté, utilisation de GIMP..."
    
    # Créer un script GIMP temporaire
    GIMP_SCRIPT=$(mktemp)
    cat > "$GIMP_SCRIPT" << 'EOF'
(define (svg-to-gif svg-file output-gif)
  (let* ((image (car (file-svg-load RUN-NONINTERACTIVE svg-file svg-file 256 256 0 0 0)))
         (drawable (car (gimp-image-get-active-layer image))))
    (file-gif-save RUN-NONINTERACTIVE
                   image
                   drawable
                   output-gif
                   output-gif
                   0 1 100 0)
    (gimp-image-delete image)))
(svg-to-gif "SVG_FILE_PLACEHOLDER" "OUTPUT_GIF_PLACEHOLDER")
(gimp-quit 0)
EOF
    
    # Remplacer les placeholders
    sed -i '' "s|SVG_FILE_PLACEHOLDER|$SVG_FILE|g" "$GIMP_SCRIPT"
    sed -i '' "s|OUTPUT_GIF_PLACEHOLDER|$OUTPUT_GIF|g" "$GIMP_SCRIPT"
    
    # Exécuter GIMP en mode batch
    gimp -i -b "$GIMP_SCRIPT" 2>/dev/null
    
    if [ -f "$OUTPUT_GIF" ]; then
        echo "✅ GIF créé avec succès : $OUTPUT_GIF"
        rm "$GIMP_SCRIPT"
        exit 0
    fi
fi

# Méthode 2 : Utiliser ImageMagick (si disponible)
if command -v convert &> /dev/null; then
    echo "✅ ImageMagick détecté..."
    echo "⚠️  ImageMagick ne peut pas directement convertir SVG animé en GIF"
    echo "   Il faut d'abord capturer l'animation frame par frame"
    echo ""
    echo "💡 Utilisez plutôt la méthode GIMP ou le script Node.js"
    exit 1
fi

# Méthode 3 : Utiliser Node.js avec puppeteer (si disponible)
if command -v node &> /dev/null; then
    echo "✅ Node.js détecté..."
    echo "💡 Utilisez le script create-gif-node.js pour capturer l'animation"
    exit 1
fi

echo "❌ Aucun outil compatible trouvé"
echo ""
echo "📦 Options disponibles :"
echo "   1. Installer GIMP (gratuit) : brew install --cask gimp"
echo "   2. Utiliser le script Node.js : node dev/scripts/create-gif-node.js"
echo "   3. Utiliser une méthode manuelle avec GIMP (voir ICON_ANIMATION_STRATEGY.md)"
exit 1

