#!/bin/bash

# Script pour exporter les versions PNG du banner depuis le SVG
# Usage: ./dev/scripts/create-banner-pngs.sh

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Chemin du répertoire du plugin (2 niveaux au-dessus de ce script)
PLUGIN_DIR="$(dirname "$(dirname "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)")")"

SVG_FILE="$PLUGIN_DIR/.wordpress-org/banner.svg"
OUTPUT_1544="$PLUGIN_DIR/.wordpress-org/banner-1544x500.png"
OUTPUT_772="$PLUGIN_DIR/.wordpress-org/banner-772x250.png"

echo -e "${YELLOW}🎨 Export des versions PNG du banner avec Inkscape...${NC}"
echo "📄 Fichier SVG : $SVG_FILE"

# Vérifier si Inkscape est installé
if ! command -v inkscape &> /dev/null
then
    echo -e "${RED}❌ Inkscape n'est pas installé. Veuillez l'installer pour utiliser ce script.${NC}"
    echo "   Sur macOS, vous pouvez utiliser Homebrew : brew install --cask inkscape"
    exit 1
fi

# Vérifier que le fichier SVG existe
if [ ! -f "$SVG_FILE" ]; then
    echo -e "${RED}❌ Le fichier SVG n'existe pas : $SVG_FILE${NC}"
    exit 1
fi

echo ""
echo -e "${YELLOW}🔄 Export en cours...${NC}"

# Exporter le banner en 1544x500px
echo "  → Export banner-1544x500.png (1544x500px)..."
inkscape --export-filename="$OUTPUT_1544" --export-width=1544 --export-height=500 "$SVG_FILE" > /dev/null 2>&1

if [ $? -eq 0 ]; then
    FILE_SIZE=$(du -h "$OUTPUT_1544" | awk '{print $1}')
    echo -e "  ${GREEN}✅ PNG créé : $OUTPUT_1544 (${FILE_SIZE})${NC}"
else
    echo -e "  ${RED}❌ Erreur lors de la création de banner-1544x500.png${NC}"
    exit 1
fi

# Exporter le banner en 772x250px
echo "  → Export banner-772x250.png (772x250px)..."
inkscape --export-filename="$OUTPUT_772" --export-width=772 --export-height=250 "$SVG_FILE" > /dev/null 2>&1

if [ $? -eq 0 ]; then
    FILE_SIZE=$(du -h "$OUTPUT_772" | awk '{print $1}')
    echo -e "  ${GREEN}✅ PNG créé : $OUTPUT_772 (${FILE_SIZE})${NC}"
else
    echo -e "  ${RED}❌ Erreur lors de la création de banner-772x250.png${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}✅ Tous les PNG ont été créés avec succès !${NC}"

