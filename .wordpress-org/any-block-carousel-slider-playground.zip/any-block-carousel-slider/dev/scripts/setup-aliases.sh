#!/bin/bash

# Script pour configurer les alias Git/SVN
# Usage: source ./scripts/setup-aliases.sh
# Ou ajouter dans ~/.zshrc ou ~/.bashrc

# Alias pour le plugin
alias nbc="cd $HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider"
alias abcs-svn="cd $HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider-svn"

# Git shortcuts
alias gst="git status"
alias gco="git checkout"
alias gaa="git add ."
alias gcm="git commit -m"
alias gps="git push"
alias gpl="git pull"
alias gd="git diff"
alias gl="git log --oneline -10"

# SVN shortcuts
alias svnst="svn status"
alias svnup="svn update"
alias svndiff="svn diff"
alias svnlog="svn log -l 10"

# Scripts du plugin (maintenant dans dev/scripts/)
alias abcs-sync="cd $HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider && ./dev/scripts/sync-to-svn.sh"
alias abcs-tag="cd $HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider && ./dev/scripts/create-svn-tag.sh"
alias abcs-assets="cd $HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider && ./dev/scripts/sync-assets.sh"
alias abcs-release="cd $HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider && ./dev/scripts/release.sh"

echo "✅ Alias configurés! Utilisez 'source ~/.zshrc' pour les activer."

