const puppeteer = require('puppeteer');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

async function createBannerGif() {
    console.log('🎬 Démarrage de la conversion Banner SVG → GIF...\n');

    // Chemins des fichiers
    const PLUGIN_DIR = path.resolve(__dirname, '../..');
    const SVG_FILE = path.join(PLUGIN_DIR, '.wordpress-org/banner.svg');

    // Déterminer quelle taille créer selon l'argument
    const args = process.argv.slice(2);
    const size = args[0] || '1544x500'; // Par défaut 1544x500

    let OUTPUT_GIF, width, height;
    if (size === '772x250') {
        OUTPUT_GIF = path.join(PLUGIN_DIR, '.wordpress-org/banner-772x250.gif');
        width = 772;
        height = 250;
    } else {
        OUTPUT_GIF = path.join(PLUGIN_DIR, '.wordpress-org/banner-1544x500.gif');
        width = 1544;
        height = 500;
    }

    const TEMP_DIR = path.join(PLUGIN_DIR, '.wordpress-org/temp-banner-frames');

    // Vérifier que le fichier SVG existe
    if (!fs.existsSync(SVG_FILE)) {
        console.error(`❌ Fichier SVG introuvable : ${SVG_FILE}`);
        process.exit(1);
    }

    // Créer le dossier temporaire pour les frames
    if (!fs.existsSync(TEMP_DIR)) {
        fs.mkdirSync(TEMP_DIR, { recursive: true });
    }

    // Lire le SVG
    let svgContent = fs.readFileSync(SVG_FILE, 'utf8');

    // Modifier le SVG pour désactiver l'animation infinie dès le départ
    svgContent = svgContent.replace(
        /animation:\s*slideMove\s+4s\s+linear\s+infinite/g,
        'animation: slideMove 4s linear 1'
    );

    // Créer une page HTML pour afficher le SVG avec fond bleu WordPress
    const html = `
<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #0073AA !important;
            display: flex;
            justify-content: center;
            align-items: center;
            width: ${width}px;
            height: ${height}px;
        }
        html {
            background: #0073AA !important;
        }
    </style>
</head>
<body>
    ${svgContent}
</body>
</html>`;

    console.log('🚀 Lancement du navigateur...');
    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
        // Pas de --transparent : on garde le fond bleu
    });

    const page = await browser.newPage();

    // Définir la taille de la page pour correspondre au banner
    await page.setViewport({
        width: width,
        height: height,
        deviceScaleFactor: 1
    });

    // Charger le HTML
    await page.setContent(html, { waitUntil: 'networkidle0' });

    // Attendre que l'animation soit chargée
    console.log('⏳ Attente du chargement de l\'animation...');
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Attendre que l'animation soit au début (translateX(0))
    console.log('🔄 Attente que l\'animation soit au début (translateX(0))...');
    const animationDuration = 4; // secondes
    let isAtStart = false;
    let waitAttempts = 0;
    const maxWaitAttempts = 50; // Maximum 5 secondes

    while (!isAtStart && waitAttempts < maxWaitAttempts) {
        const currentTransform = await page.evaluate(() => {
            const slideContainer = document.querySelector('.slide-container');
            if (slideContainer) {
                const style = window.getComputedStyle(slideContainer);
                return style.transform;
            }
            return 'none';
        });

        // Vérifier si on est à translateX(0) - matrix(1, 0, 0, 1, 0, 0) ou très proche
        let isZero = currentTransform === 'none' || currentTransform === 'matrix(1, 0, 0, 1, 0, 0)';

        if (!isZero && currentTransform.includes('matrix')) {
            // Extraire la valeur X de la transformation matrix(a, b, c, d, x, y)
            const match = currentTransform.match(/matrix\([^,]+,\s*[^,]+,\s*[^,]+,\s*[^,]+,\s*([^,)]+)/);
            if (match && match[1]) {
                const xValue = parseFloat(match[1]);
                isZero = Math.abs(xValue) < 5; // Tolérance de 5px
            }
        }

        if (isZero) {
            isAtStart = true;
            console.log(`   Animation au début (tentative ${waitAttempts + 1})`);
            break;
        }

        await new Promise(resolve => setTimeout(resolve, 100));
        waitAttempts++;
    }

    // Maintenant arrêter l'animation et la relancer avec 1 itération
    console.log('🔄 Arrêt de l\'animation...');
    await page.evaluate(() => {
        const slideContainer = document.querySelector('.slide-container');
        if (slideContainer) {
            slideContainer.style.animation = 'none';
            slideContainer.style.transform = 'translateX(0)';
            void slideContainer.offsetWidth;
        }
    });

    await new Promise(resolve => setTimeout(resolve, 100));

    // Utiliser JavaScript pour animer manuellement la transformation
    console.log('▶️  Lancement de l\'animation manuelle (1 itération)...');

    // Arrêter l'animation CSS et utiliser JavaScript pour animer
    await page.evaluate(() => {
        const slideContainer = document.querySelector('.slide-container');
        if (slideContainer) {
            // Arrêter l'animation CSS
            slideContainer.style.animation = 'none';
            // Commencer à translateX(0)
            slideContainer.style.transform = 'translateX(0)';
        }
    });

    await new Promise(resolve => setTimeout(resolve, 50));

    const captureFps = 30; // Fréquence de capture (30 images par seconde pour une animation très fluide)
    const totalFrames = Math.floor(captureFps * animationDuration); // 120 frames pour 4 secondes à 30 fps
    const frameDelay = 1000 / captureFps; // ~33ms entre chaque capture

    console.log(`📸 Capture de ${totalFrames} frames à ${captureFps} fps pendant ${animationDuration}s...`);
    console.log(`   Taille : ${width}x${height}px`);
    console.log(`   Animation lancée une seule fois, capture à vitesse normale`);

    const startTime = Date.now();

    // Vérifier la transformation initiale
    const initialTransform = await page.evaluate(() => {
        const slideContainer = document.querySelector('.slide-container');
        return slideContainer ? window.getComputedStyle(slideContainer).transform : 'none';
    });
    console.log(`   Transform initiale : ${initialTransform}`);

    for (let i = 0; i < totalFrames; i++) {
        // Calculer le temps écoulé depuis le début de la capture (pas depuis animationStartTime)
        // Chaque frame doit correspondre à un moment précis de l'animation de 4 secondes
        const progress = Math.min(i / totalFrames, 1); // 0 à 1 basé sur le numéro de frame

        // Calculer la transformation selon l'animation slideMove
        // Animation slideMove : 
        // 0-25% : translateX(0) (slide 1)
        // 25-50% : translateX(0) → translateX(-242) (transition)
        // 50-75% : translateX(-242) (slide 2)
        // 75-100% : translateX(-242) → translateX(0) (retour instantané, mais on ne capture que jusqu'à 75%)

        let translateX = 0;
        if (progress <= 0.25) {
            // 0-25% : slide 1 visible
            translateX = 0;
        } else if (progress <= 0.50) {
            // 25-50% : transition de 0 à -242
            const transitionProgress = (progress - 0.25) / 0.25; // 0 à 1
            translateX = -242 * transitionProgress;
        } else {
            // 50-75% : slide 2 visible
            translateX = -242;
        }

        // Appliquer la transformation
        await page.evaluate((tx) => {
            const slideContainer = document.querySelector('.slide-container');
            if (slideContainer) {
                slideContainer.style.transform = `translateX(${tx}px)`;
            }
        }, translateX);

        const framePath = path.join(TEMP_DIR, `frame-${String(i).padStart(3, '0')}.png`);
        await page.screenshot({
            path: framePath,
            clip: { x: 0, y: 0, width: width, height: height }
            // Pas de omitBackground : on garde le fond bleu
        });

        // Calculer le temps écoulé et ajuster le délai pour rester synchronisé
        const elapsedTime = Date.now() - startTime;
        const expectedTime = (i + 1) * frameDelay;
        const waitTime = Math.max(0, expectedTime - elapsedTime);

        if (waitTime > 0) {
            await new Promise(resolve => setTimeout(resolve, waitTime));
        }

        if ((i + 1) % 10 === 0) {
            process.stdout.write(`\r   ${i + 1}/${totalFrames} frames capturées...`);
        }
    }

    // Arrêter l'animation après la capture
    await page.evaluate(() => {
        const slideContainer = document.querySelector('.slide-container');
        if (slideContainer) {
            slideContainer.style.animation = 'none';
        }
    });

    console.log('\n✅ Frames capturées');

    // Lister tous les fichiers frames dans l'ordre
    const frameFiles = [];
    for (let i = 0; i < totalFrames; i++) {
        const framePath = path.join(TEMP_DIR, `frame-${String(i).padStart(3, '0')}.png`);
        if (fs.existsSync(framePath)) {
            frameFiles.push(framePath);
        }
    }

    if (frameFiles.length === 0) {
        console.error('❌ Aucune frame capturée');
        await browser.close();
        process.exit(1);
    }

    // Détecter ImageMagick
    let convertCmd = 'convert';
    let isMagick = false;
    try {
        execSync('which magick', { stdio: 'ignore' });
        convertCmd = 'magick';
        isMagick = true;
    } catch (e) {
        try {
            execSync('which convert', { stdio: 'ignore' });
        } catch (e2) {
            console.error('❌ ImageMagick n\'est pas installé');
            await browser.close();
            process.exit(1);
        }
    }

    console.log('🎞️  Création du GIF avec fond bleu...');

    // Créer le GIF avec les frames transparentes
    // Le délai en ImageMagick est en centièmes de seconde (100 = 1 seconde)
    // Pour 10 fps : chaque frame doit durer 0.1s = 10/100 seconde
    // Pour 40 frames à 0.1s chacune : 40 × 0.1s = 4 secondes (parfait !)
    const gifDelay = (1000 / captureFps) / 10; // 100ms = 10 en unités ImageMagick (100 = 1 seconde)

    console.log(`   Délai par frame dans le GIF : ${gifDelay}/100 seconde (${(gifDelay / 100).toFixed(3)}s)`);
    console.log(`   Durée totale du GIF : ${(totalFrames * gifDelay / 100).toFixed(2)} secondes`);

    // Utiliser le délai calculé (10 pour 0.1s par frame)
    // 40 frames × 0.1s = 4 secondes exactement
    if (isMagick) {
        cmd = `${convertCmd} -delay ${gifDelay} -loop 0 ${frameFiles.map(f => `"${f}"`).join(' ')} "${OUTPUT_GIF}"`;
    } else {
        cmd = `${convertCmd} -delay ${gifDelay} -loop 0 ${frameFiles.map(f => `"${f}"`).join(' ')} "${OUTPUT_GIF}"`;
    }

    execSync(cmd, { stdio: 'inherit' });

    // Nettoyer
    console.log('🧹 Nettoyage des fichiers temporaires...');
    for (const frameFile of frameFiles) {
        fs.unlinkSync(frameFile);
    }
    fs.rmdirSync(TEMP_DIR);

    await browser.close();

    // Afficher la taille du fichier
    const stats = fs.statSync(OUTPUT_GIF);
    const fileSizeKB = (stats.size / 1024).toFixed(2);

    console.log(`\n✅ GIF créé avec succès : ${OUTPUT_GIF}`);
    console.log(`📊 Taille : ${fileSizeKB} KB`);
}

// Exécuter
createBannerGif().catch(error => {
    console.error('❌ Erreur :', error);
    process.exit(1);
});

