# Quick Start - Structure du Projet

## 🎯 Principe Simple

**Tout ce qui est à la racine = Publié**  
**Tout ce qui est dans `dev/` = Local uniquement**

## 📁 Structure Visuelle

```
any-block-carousel-slider/
│
├── ✅ PUBLIÉ (GitHub + WordPress.org)
│   ├── any-block-carousel-slider.php
│   ├── readme.txt
│   ├── LICENSE
│   ├── includes/
│   ├── assets/
│   └── languages/
│
└── ❌ dev/ (JAMAIS publié)
    ├── ARCHITECTURE.md
    ├── docs/
    └── scripts/
```

## 🚀 Commandes Rapides

```bash
# Aller au plugin
nbc

# Voir ce qui sera publié
git ls-files

# Synchroniser vers SVN
./dev/scripts/sync-to-svn.sh

# Release complète
./dev/scripts/release.sh 1.0.2 "Description"
```

## ✅ Vérification

```bash
# Vérifier que dev/ est ignoré
git check-ignore dev/
# Devrait afficher : dev/ ✅

# Voir le statut
git status
# dev/ ne devrait jamais apparaître ✅
```

## 📝 Règles d'Or

1. ✅ **Fichiers de production** → À la racine
2. ✅ **Fichiers de développement** → Dans `dev/`
3. ✅ **Un seul dossier à ignorer** → `dev/`
4. ✅ **GitHub = WordPress.org** → Mêmes fichiers

---

**C'est tout ! Simple et efficace.** 🎉

