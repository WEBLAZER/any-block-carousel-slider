# Dossier de Développement - Any Block Carousel Slider

Ce dossier contient **uniquement** les fichiers de développement. Il est **complètement ignoré** par Git et SVN.

## 🔒 Sécurité

**Ce dossier ne sera JAMAIS publié sur :**
- ❌ GitHub
- ❌ WordPress.org SVN

Vous pouvez y mettre tout ce qui est nécessaire au développement sans risque.

## 📁 Contenu

```
dev/
├── README.md                    # Ce fichier
├── ARCHITECTURE.md             # Documentation technique
├── docs/                        # Documentation interne
│   ├── COMPLIANCE_REPORT.md
│   ├── PRE_SUBMISSION_CHECKLIST.md
│   ├── SEO_AUDIT_COMPETITOR.md
│   ├── WORKFLOW_OPTIMIZATION.md
│   └── WORKFLOW_QUOTIDIEN.md
└── scripts/                     # Scripts d'automatisation
    ├── sync-to-svn.sh
    ├── create-svn-tag.sh
    ├── sync-assets.sh
    ├── release.sh
    └── setup-aliases.sh
```

## ✅ Fichiers Publiés (à la racine)

Seuls ces fichiers seront publiés :

```
any-block-carousel-slider/
├── any-block-carousel-slider.php   ✅ Plugin principal
├── readme.txt                   ✅ Description WordPress.org
├── LICENSE                      ✅ Licence GPL
├── includes/                    ✅ Code PHP
├── assets/                      ✅ CSS et JS
└── languages/                   ✅ Traductions
```

## 🎯 Avantages

1. **Clarté visuelle** : Vous voyez immédiatement ce qui sera publié
2. **Sécurité** : Impossible de publier accidentellement des fichiers sensibles
3. **Organisation** : Tout le développement au même endroit
4. **Simplicité** : Un seul dossier à ignorer

## 📝 Utilisation

### Ajouter un fichier de développement

```bash
# Créer dans dev/
touch dev/nouveau-fichier.md

# Automatiquement ignoré ✅
```

### Utiliser les scripts

```bash
# Les scripts sont dans dev/scripts/
./dev/scripts/sync-to-svn.sh
./dev/scripts/release.sh 1.0.2
```

### Vérifier ce qui sera publié

```bash
# Voir les fichiers trackés par Git
git ls-files

# Voir ce qui sera sync vers SVN
# (tous les fichiers sauf dev/)
```

## 🔍 Vérification

Pour vérifier qu'un fichier ne sera pas publié :

```bash
# Vérifier Git
git check-ignore dev/mon-fichier.md
# Devrait afficher : dev/mon-fichier.md ✅

# Vérifier le statut
git status
# dev/ ne devrait jamais apparaître ✅
```

## ⚠️ Important

**Ne jamais :**
- ❌ Commit manuellement des fichiers de `dev/`
- ❌ Ajouter `dev/` au staging
- ❌ Modifier `.gitignore` pour inclure `dev/`

**Toujours :**
- ✅ Utiliser les scripts de sync (excluent automatiquement `dev/`)
- ✅ Vérifier `git status` avant commit
- ✅ Garder `dev/` pour usage local uniquement

## 🚀 Workflow

1. **Développement** : Travailler normalement, fichiers dans `dev/` si nécessaire
2. **Commit** : Seuls les fichiers à la racine sont trackés
3. **Sync SVN** : Le script exclut automatiquement `dev/`
4. **Résultat** : GitHub et WordPress.org ont exactement les mêmes fichiers ✅

