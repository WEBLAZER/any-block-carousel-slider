# Documentation de Développement - Any Block Carousel Slider

Ce dossier contient la documentation interne de développement du plugin. Ces fichiers sont **uniquement pour le développement local** et ne sont **pas publiés** sur GitHub ni WordPress.org.

## 📁 Fichiers Disponibles

- **COMPLIANCE_REPORT.md** - Rapport de conformité WordPress.org
- **PRE_SUBMISSION_CHECKLIST.md** - Checklist avant soumission
- **SEO_AUDIT_COMPETITOR.md** - Audit SEO du concurrent
- **WORKFLOW_OPTIMIZATION.md** - Guide d'optimisation du workflow
- **WORKFLOW_QUOTIDIEN.md** - Guide du workflow quotidien

## 🔒 Sécurité

Ces fichiers peuvent contenir :
- Chemins personnels
- Informations sensibles
- Stratégies internes
- Analyses concurrentielles

**Ils ne doivent JAMAIS être commités sur GitHub ou synchronisés vers WordPress.org SVN.**

## ✅ Vérification

Les scripts de synchronisation excluent automatiquement ce dossier :
- `scripts/sync-to-svn.sh` - Exclut `docs/` et tous les `.md`
- `.gitignore` - Exclut `docs/` de Git

## 📝 Note

Si vous devez partager de la documentation :
- Créer un `README.md` à la racine (sera publié)
- Ou utiliser `ARCHITECTURE.md` (sera publié sur GitHub uniquement)

