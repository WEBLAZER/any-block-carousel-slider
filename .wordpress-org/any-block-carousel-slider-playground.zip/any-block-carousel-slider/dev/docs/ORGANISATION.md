# Organisation des Fichiers de Documentation

## 📁 Structure

```
any-block-carousel-slider/
├── README.md                    # ✅ Publié sur GitHub (si créé)
├── ARCHITECTURE.md              # ✅ Publié sur GitHub uniquement
├── docs/                        # ❌ JAMAIS publié
│   ├── README.md               # Guide de ce dossier
│   ├── COMPLIANCE_REPORT.md    # Rapport de conformité
│   ├── PRE_SUBMISSION_CHECKLIST.md
│   ├── SEO_AUDIT_COMPETITOR.md
│   ├── WORKFLOW_OPTIMIZATION.md
│   └── WORKFLOW_QUOTIDIEN.md
└── scripts/                     # ❌ JAMAIS publié
    └── ...
```

## ✅ Fichiers Publiés

### GitHub uniquement
- **ARCHITECTURE.md** - Documentation technique (utile pour les contributeurs)

### GitHub + WordPress.org
- **readme.txt** - Description du plugin (requis WordPress.org)
- **README.md** - Si créé, sera publié partout

## ❌ Fichiers NON Publiés

Tous les fichiers dans `docs/` et `scripts/` sont exclus de :
- ✅ GitHub (via `.gitignore`)
- ✅ WordPress.org SVN (via `scripts/sync-to-svn.sh`)

## 🔒 Pourquoi cette Organisation ?

1. **Sécurité** : Les fichiers `docs/` peuvent contenir des chemins personnels, stratégies internes
2. **Propreté** : WordPress.org n'a pas besoin de documentation de développement
3. **Clarté** : Séparation claire entre documentation publique et interne

## 📝 Ajouter un Nouveau Fichier

### Pour GitHub uniquement
```bash
# Créer à la racine
touch NOUVEAU_FICHIER.md

# Vérifier qu'il n'est pas dans .gitignore
git check-ignore NOUVEAU_FICHIER.md
# (ne doit rien retourner)
```

### Pour documentation interne
```bash
# Créer dans docs/
touch docs/NOUVEAU_FICHIER.md

# Automatiquement exclu de Git et SVN
```

## 🔍 Vérification

Pour vérifier qu'un fichier ne sera pas publié :

```bash
# Vérifier Git
git check-ignore chemin/fichier.md

# Si rien ne s'affiche = sera commité
# Si le chemin s'affiche = sera ignoré ✅
```

## 🚨 Important

**Ne jamais :**
- ❌ Commit manuellement des fichiers de `docs/`
- ❌ Ajouter `docs/` au staging
- ❌ Modifier `.gitignore` pour inclure `docs/`

**Toujours :**
- ✅ Utiliser les scripts de sync (excluent automatiquement)
- ✅ Vérifier `git status` avant commit
- ✅ Garder `docs/` pour usage local uniquement

