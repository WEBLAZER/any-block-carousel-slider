# Checklist Pré-Soumission WordPress.org

## ✅ Fichiers et Structure

- [x] **Fichier principal** : `any-block-carousel-slider.php` ✓
- [x] **readme.txt** : En anglais, format conforme ✓
- [x] **LICENSE** : GPLv2 présent ✓
- [x] **Text Domain** : Configuré (`any-block-carousel-slider`) ✓
- [x] **Screenshots** : 5 images présentes dans `.wordpress-org/` ✓
- [x] **Bannières** : `banner-1544x500.png`, `banner-772x250.png`, `banner.svg` ✓
- [x] **Icônes** : `icon-256x256.png`, `icon.svg` ✓

## 📋 Dernières Vérifications

### 1. Assets WordPress.org

Vérifier que les fichiers dans `.wordpress-org/` sont corrects :

- [ ] **Banner 1544x500px** : Image haute qualité, représente le plugin
- [ ] **Banner 772x250px** : Version réduite, lisible
- [ ] **Banner SVG** : Version vectorielle (optionnel mais recommandé)
- [ ] **Icon 256x256px** : Icône carrée, lisible à petite taille
- [ ] **Icon SVG** : Version vectorielle (optionnel mais recommandé)
- [ ] **Screenshots 1-5** : Correspondent aux descriptions dans readme.txt

### 2. Vérification du Code

- [ ] Exécuter **Plugin Check** : https://wordpress.org/plugins/plugin-check/
  - Installer le plugin
  - Aller dans **Outils > Plugin Check**
  - Sélectionner "Any Block Carousel Slider"
  - Corriger tous les warnings/errors

- [ ] Vérifier les warnings PHP :
  ```bash
  php -l any-block-carousel-slider.php
  php -l includes/*.php
  ```

- [ ] Tester l'activation/désactivation :
  - Activer le plugin
  - Vérifier qu'aucune erreur n'apparaît
  - Désactiver le plugin
  - Réactiver

### 3. Tests de Compatibilité

- [ ] **WordPress 6.0** (version minimale)
- [ ] **WordPress 6.8** (version testée)
- [ ] **PHP 7.4** (version minimale)
- [ ] **PHP 8.1+** (versions récentes)
- [ ] **Thème block** (Twenty Twenty-Four)
- [ ] **Thème classique** (Twenty Twenty-Three)
- [ ] **WooCommerce** (si applicable)

### 4. Vérification du readme.txt

- [x] Description courte optimisée SEO ✓
- [x] Tags limités à 5 mots-clés stratégiques ✓
- [x] Section Description complète ✓
- [x] FAQ détaillée ✓
- [x] Changelog à jour ✓
- [x] Screenshots décrits (5) ✓
- [ ] Vérifier qu'aucun lien cassé
- [ ] Vérifier l'orthographe/grammaire (anglais)

### 5. Fichiers à Exclure du SVN

Le dossier `.wordpress-org/` sera automatiquement géré par WordPress.org lors de la synchronisation SVN.

**Fichiers à NE PAS inclure dans le ZIP de soumission** :
- `.git/` (dossier Git)
- `.gitignore`
- `ARCHITECTURE.md` (documentation interne)
- `COMPLIANCE_REPORT.md` (rapport interne)
- `PRE_SUBMISSION_CHECKLIST.md` (ce fichier)
- `node_modules/` (si présent)
- `vendor/` (si présent)
- Fichiers de développement

**Fichiers à INCLURE** :
- `any-block-carousel-slider.php`
- `readme.txt`
- `LICENSE`
- `includes/` (tous les fichiers PHP)
- `assets/` (CSS et JS)
- `languages/` (fichiers de traduction)

## 🚀 Processus de Soumission

### Étape 1 : Préparer le ZIP

1. Créer un dossier temporaire
2. Copier uniquement les fichiers nécessaires (voir liste ci-dessus)
3. **NE PAS inclure** `.wordpress-org/` dans le ZIP (sera géré par SVN)
4. Créer un ZIP nommé `any-block-carousel-slider.zip`

### Étape 2 : Soumettre sur WordPress.org

1. Aller sur : https://wordpress.org/plugins/developers/add/
2. Se connecter avec votre compte WordPress.org
3. Remplir le formulaire :
   - **Plugin Name** : Any Block Carousel Slider
   - **Plugin Slug** : `any-block-carousel-slider` (sera généré automatiquement)
   - **Short Description** : Copier depuis readme.txt ligne 12
   - **Upload Plugin** : Sélectionner le ZIP
4. Soumettre

### Étape 3 : Révision

- L'équipe WordPress.org examinera votre plugin (2-7 jours généralement)
- Vous recevrez un email avec :
  - ✅ Approbation + accès SVN
  - ⚠️ Demandes de modifications
  - ❌ Rejet (rare, avec explications)

### Étape 4 : Après Approbation

1. **Accès SVN** : Vous recevrez les identifiants SVN
2. **Synchronisation** : Utiliser `svn` ou un outil comme `svn2git`
3. **Première version** : Commiter votre code dans `trunk/`
4. **Tag de version** : Créer un tag `1.0.1/` dans `tags/`
5. **Assets** : Les fichiers `.wordpress-org/` seront automatiquement détectés

## 📝 Notes Importantes

### À propos de `.wordpress-org/`

- Ce dossier contient les assets visuels (bannières, icônes, screenshots)
- WordPress.org les détecte automatiquement lors de la synchronisation SVN
- **Ne pas inclure** dans le ZIP initial de soumission
- Les assets seront uploadés après l'approbation via SVN

### À propos de `.git/`

- Le dossier Git est pour votre développement local
- **Ne pas inclure** dans le ZIP de soumission
- WordPress.org utilise SVN, pas Git
- Vous pouvez synchroniser Git ↔ SVN avec des outils comme `git-svn`

### Workflow Recommandé

1. **Développement** : Utiliser Git (GitHub, GitLab, etc.)
2. **Soumission** : Créer un ZIP propre sans fichiers de dev
3. **Après approbation** : Synchroniser avec SVN
4. **Mises à jour** : Push vers Git, puis sync vers SVN

## ✅ Statut Actuel

**Prêt pour soumission** : ✅ OUI

Tous les fichiers requis sont présents. Il reste à :
1. Exécuter Plugin Check et corriger les warnings
2. Tester sur différentes versions WordPress/PHP
3. Créer le ZIP de soumission (sans fichiers de dev)
4. Soumettre sur WordPress.org

---

**Dernière mise à jour** : 2025-01-24  
**Version du plugin** : 1.0.1

