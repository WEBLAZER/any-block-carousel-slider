# Animation de l'Icône - Any Block Carousel Slider

## 🎨 Icône Animée SVG

L'icône du plugin est maintenant animée pour montrer l'effet de carrousel en action.

### Animations Incluses

1. **Défilement des slides** (3s, boucle infinie)
   - 3 cartes qui défilent de droite à gauche
   - Animation fluide avec `ease-in-out`
   - Boucle continue pour montrer le mouvement

2. **Pulse des flèches** (2s, boucle infinie)
   - Flèches gauche et droite qui pulsent légèrement
   - Délai décalé pour effet alterné
   - Attire l'attention sur les contrôles

3. **Animation des points** (3s, boucle infinie)
   - Les points de pagination suivent le slide actif
   - Le point actif grossit et s'éclaircit
   - Synchronisé avec le défilement

### Fichiers

- **icon.svg** : Version animée (remplace l'ancienne)
- **icon-256x256.png** : Version statique PNG (fallback)

### Compatibilité

- ✅ **SVG animé** : Fonctionne dans la plupart des navigateurs modernes
- ✅ **WordPress.org** : Accepte les SVG animés pour les icônes
- ✅ **Léger** : SVG animé = très léger (~2-3KB)
- ✅ **Scalable** : S'adapte à toutes les tailles

### Alternative : GIF Animé

Si vous préférez un GIF animé pour compatibilité maximale :

1. **Créer un GIF** depuis le SVG animé
   - Utiliser un outil comme GIMP, Photoshop, ou en ligne
   - Exporter en GIF animé (256x256px)
   - Durée : 3 secondes, boucle infinie

2. **Renommer** : `icon-256x256.gif`

3. **Avantages GIF** :
   - ✅ Compatibilité maximale (tous les navigateurs)
   - ✅ Fonctionne partout (même anciens navigateurs)
   - ✅ Populaire sur WordPress.org

4. **Inconvénients GIF** :
   - ⚠️ Plus lourd que SVG (~50-100KB)
   - ⚠️ Pas scalable (pixelisé si agrandi)

### Recommandation

**Utiliser le SVG animé** car :
- ✅ Plus léger
- ✅ Scalable
- ✅ Moderne
- ✅ Fonctionne sur WordPress.org

Le GIF peut être une option de fallback si nécessaire.

### Test de l'Animation

Pour tester l'icône animée :

1. Ouvrir `icon.svg` dans un navigateur moderne
2. L'animation devrait se lancer automatiquement
3. Vérifier que le défilement est fluide

### Personnalisation

Pour ajuster l'animation, modifier les valeurs dans `<style>` :

```css
/* Vitesse du défilement */
@keyframes slide {
    0% { transform: translateX(0); }
    33.33% { transform: translateX(-85px); }
    66.66% { transform: translateX(-170px); }
    100% { transform: translateX(0); }
}

/* Durée : 3s = rapide, 5s = lent */
.slides-container {
    animation: slide 3s ease-in-out infinite;
}
```

### Outils pour Créer un GIF

Si vous voulez créer un GIF animé :

1. **En ligne** : 
   - [ezgif.com](https://ezgif.com/svg-to-gif)
   - [cloudconvert.com](https://cloudconvert.com/svg-to-gif)

2. **Logiciels** :
   - GIMP (gratuit)
   - Photoshop
   - After Effects

3. **Command line** (si ImageMagick installé) :
   ```bash
   # Convertir SVG en frames PNG
   # Puis créer GIF avec ImageMagick
   convert -delay 10 -loop 0 frame*.png icon-256x256.gif
   ```

---

**Note** : WordPress.org accepte les deux formats (SVG animé et GIF animé) pour les icônes de plugins.

