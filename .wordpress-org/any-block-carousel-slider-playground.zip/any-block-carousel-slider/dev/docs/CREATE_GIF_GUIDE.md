# Guide : Créer un GIF Animé depuis icon.svg

## 🎯 Objectif

Convertir `icon.svg` (animé) en `icon-256x256.gif` pour une compatibilité maximale sur WordPress.org.

## 📋 Méthodes Disponibles

### Méthode 1 : GIMP (Recommandé - Gratuit et Simple) ⭐

**GIMP est la solution la plus simple et gratuite.**

#### Installation (macOS)

```bash
brew install --cask gimp
```

#### Étapes dans GIMP

1. **Ouvrir GIMP**

2. **Importer le SVG** :
   - `Fichier` → `Ouvrir` → Sélectionner `icon.svg`
   - GIMP va importer le SVG avec l'animation

3. **Créer l'animation GIF** :
   - `Fichier` → `Exporter sous...`
   - Nommer le fichier : `icon-256x256.gif`
   - Dans la fenêtre d'export, cocher **"En tant qu'animation"**
   - Paramètres recommandés :
     - **Délai entre frames** : 100 ms (10 fps)
     - **Boucle** : Infinie
     - **Déplacement** : Remplacer
     - **Délai où non spécifié** : 100 ms

4. **Exporter** :
   - Cliquer sur `Exporter`
   - Le GIF sera créé dans `.wordpress-org/icon-256x256.gif`

#### Avantages
- ✅ Gratuit
- ✅ Interface graphique simple
- ✅ Supporte les SVG animés
- ✅ Contrôle total sur les paramètres

---

### Méthode 2 : Script Node.js (Automatisé) 🤖

**Pour les développeurs qui préfèrent l'automatisation.**

#### Prérequis

```bash
# Installer Node.js (si pas déjà installé)
brew install node

# Installer ImageMagick
brew install imagemagick

# Installer puppeteer dans le plugin
cd wp-content/plugins/any-block-carousel-slider
npm install puppeteer
```

#### Utilisation

```bash
node dev/scripts/create-gif-node.js
```

Le script va :
1. Lancer un navigateur headless
2. Capturer l'animation SVG frame par frame
3. Créer le GIF avec ImageMagick
4. Nettoyer les fichiers temporaires

#### Avantages
- ✅ Automatique
- ✅ Répétable
- ✅ Contrôle précis (fps, durée)

---

### Méthode 3 : Illustrator + Extension GIFStudio 💰

**Si vous avez déjà Illustrator.**

1. **Installer l'extension GIFStudio** pour Illustrator
2. Ouvrir `icon.svg` dans Illustrator
3. Utiliser GIFStudio pour exporter en GIF

**Note** : Cette extension est payante et peut ne pas être nécessaire si vous avez GIMP.

---

### Méthode 4 : Inkscape + GIMP (Gratuit) 🆓

**Alternative à GIMP seul.**

1. **Installer Inkscape et GIMP** :
   ```bash
   brew install --cask inkscape
   brew install --cask gimp
   ```

2. **Dans Inkscape** :
   - Ouvrir `icon.svg`
   - Exporter chaque frame en PNG (manuel, fastidieux)

3. **Dans GIMP** :
   - Importer tous les PNG comme calques
   - Exporter en GIF animé

**Note** : Cette méthode est fastidieuse car Inkscape ne gère pas directement les animations SVG.

---

## 🎨 Paramètres Recommandés pour le GIF

- **Dimensions** : 256×256px (exactement)
- **Durée** : 4 secondes (comme le SVG)
- **FPS** : 10 images/seconde (suffisant pour une animation fluide)
- **Boucle** : Infinie
- **Qualité** : Optimale
- **Taille attendue** : ~50-100 KB

## ✅ Vérification

Après création, vérifier le GIF :

1. **Ouvrir dans un navigateur** : `icon-256x256.gif`
2. **Vérifier** :
   - ✅ L'animation démarre automatiquement
   - ✅ La boucle est fluide
   - ✅ Pas de saccades
   - ✅ Les couleurs sont correctes

## 🚀 Recommandation Finale

**Utilisez GIMP (Méthode 1)** - C'est la solution la plus simple, gratuite et efficace pour convertir un SVG animé en GIF.

---

## 📝 Troubleshooting

### GIMP n'importe pas l'animation

- Vérifier que le SVG contient bien les animations CSS (`@keyframes`)
- Essayer d'ouvrir le SVG dans un navigateur d'abord pour vérifier l'animation
- GIMP peut avoir des limitations avec certaines animations SVG complexes

### Le GIF est trop lourd

- Réduire la qualité dans GIMP
- Réduire le nombre de frames (8 fps au lieu de 10)
- Utiliser une palette de couleurs réduite

### Le GIF ne boucle pas

- Vérifier les paramètres d'export dans GIMP
- Cocher "Boucle infinie" dans les options d'export

